//
//  AppDelegate.h
//  InshortsTest
//
//  Created by Vikrant Sharma on 08/12/16.
//  Copyright © 2016 VikrantSharma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

