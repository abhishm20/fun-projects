[![Stories in Ready](https://badge.waffle.io/rizdroid/INSHORT_DEMO.png?label=ready&title=Ready)](https://waffle.io/rizdroid/INSHORT_DEMO)
INSHORT LIKE CONTENT SWIPE FEATURE SAMPLE APP 
watch the video of app :
https://youtu.be/qgrsCOLM0LA
